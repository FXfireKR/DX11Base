﻿#pragma once
#include <cstdint>

using BLOCK_ID = uint32_t;
using PROPERTY_ID = uint16_t;
using VALUE_INDEX = uint8_t;	// property 내부 값 인덱스
using STATE_INDEX = uint16_t;	// 블록 당 상태 조합수 65535 이하로 가정
using PROP_HASH = uint64_t;
using VALUE_HASH = uint64_t;