﻿#pragma once
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "VoxelTypes.h"

using BlockPropHashMap = std::unordered_map<PROP_HASH, VALUE_HASH>;

struct GlobalPropertyRegistry
{
	std::unordered_map<PROP_HASH, PROPERTY_ID> mapNameHashToID;
	std::vector<std::string> vecIDToName;

	PROPERTY_ID GetOrCreate(const std::string& name);
	bool Find(const std::string& name, PROPERTY_ID& outPropID) const;
	bool FindByHash(PROP_HASH nameHash, PROPERTY_ID& outPropID) const;
};